import requests
from flask import Flask, jsonify, request, abort, g
from db_manager import DBManager
from functools import wraps
import uuid

# Initialize the Flask app and the database manager
app = Flask(__name__)
db = DBManager("trivia_game.db")